import yaml
from flask import Flask, request, render_template, session, redirect

app = Flask(__name__)
app.config["SECRET_KEY"] = "harbor-light-dev-7f3a"


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/login", methods=["POST"])
def login():
    session["user"] = request.form.get("username")
    return redirect("/")


@app.route("/api/import", methods=["POST"])
def import_settings():
    # settings arrive as YAML
    doc = request.form.get("settings")
    settings = yaml.load(doc, Loader=yaml.Loader)
    return {"imported": len(settings)}


@app.get("/health")
def health():
    return "ok"
